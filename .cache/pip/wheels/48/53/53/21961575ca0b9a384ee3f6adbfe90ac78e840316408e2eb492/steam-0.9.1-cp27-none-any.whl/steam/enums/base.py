from enum import IntEnum


class SteamIntEnum(IntEnum):
    pass
